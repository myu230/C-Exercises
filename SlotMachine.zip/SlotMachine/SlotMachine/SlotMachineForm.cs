﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SlotMachine
{
    public partial class SlotMachineForm : Form
    {
        private Slot[] m_slots = { new Slot(), new Slot(), new Slot() };
        private int m_winCount = 0;

        public SlotMachineForm()
        {
            InitializeComponent();
            m_slots[0].SlotChanged += m_slots_Slot1Changed;
            m_slots[1].SlotChanged += m_slots_Slot2Changed;
            m_slots[2].SlotChanged += m_slots_Slot3Changed;
        }

        ~SlotMachineForm()
        {
            m_slots[0].SlotChanged -= m_slots_Slot1Changed;
            m_slots[1].SlotChanged -= m_slots_Slot2Changed;
            m_slots[2].SlotChanged -= m_slots_Slot3Changed;
        }


        private void tmrPlay_Tick(object sender, EventArgs e)
        {
            for (int i = 0; i < m_slots.Length; i++)
                m_slots[i].Play();
            if (m_slots[0].SlotValue == m_slots[1].SlotValue & m_slots[1].SlotValue == m_slots[2].SlotValue)
            {
                m_winCount++;
                lblMessage.Text = String.Format("# of Wins: {0}", m_winCount);
            }
        }

        private void m_slots_Slot1Changed(object sender, EventArgs e)
        {
            lblSlot1.Text = String.Format("{0}", m_slots[0].SlotValue);
        }

        private void m_slots_Slot2Changed(object sender, EventArgs e)
        {
            lblSlot2.Text = String.Format("{0}", m_slots[1].SlotValue);
        }

        private void m_slots_Slot3Changed(object sender, EventArgs e)
        {
            lblSlot3.Text = String.Format("{0}", m_slots[2].SlotValue);
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }


    }
}
