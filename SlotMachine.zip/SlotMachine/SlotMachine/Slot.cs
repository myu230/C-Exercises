﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SlotMachine
{
    public class Slot
    {
        public int SlotValue { get; private set; }
        private static Random m_rnd = new Random();

        public event EventHandler SlotChanged;

        public void Play()
        {
            int oldSlot = SlotValue;
            SlotValue = m_rnd.Next(1, 10);

            if (oldSlot != SlotValue && SlotChanged != null)
            {
                SlotChanged(this, new EventArgs());
            }
  
        }      
    }
}
