﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LabExercise1
{
    public partial class BillCalculator : Form
    {
        public BillCalculator()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            decimal dAmount, dTipAmount, dTaxAmount, dTotalAmount;
            double dbTax, dbTip;
            bool bTax, bTip;
            dAmount = Convert.ToDecimal(txtAmount.Text);

            bTax = double.TryParse(txtTaxRate.Text, out dbTax);
            bTip = double.TryParse(txtTipPercentage.Text, out dbTip);

            if ((!bTax) || (dbTax < 0) || (dbTax > 100))
            {
                dbTax = 0;
                MessageBox.Show("Not a valid tax rate.", "Invalid Tax Rate", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

            if ((!bTip) || (dbTip < 0) || (dbTip > 100))
            {
                dbTip = 0;
                MessageBox.Show("Not a valid tip percentage", "Invalid Tip Percentage", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

            dTaxAmount =  Convert.ToDecimal(dbTax/100.0)*dAmount;
            dTipAmount = Convert.ToDecimal(dbTip / 100.0) * dAmount;
            dTotalAmount = dAmount+dTipAmount+dTaxAmount;

            lblNumAmount.Text = string.Format("{0,10:C2}", dAmount);
            lblNumTax.Text = string.Format("{0,10:C2}", dTaxAmount);
            lblNumTip.Text = string.Format("{0,10:C2}", dTipAmount);
            lblNumTotal.Text = string.Format("{0,10:C2}", dTotalAmount);
        }

        private void txtAmount_TextChanged(object sender, EventArgs e)
        {
            decimal dummy;
            btnCalculate.Enabled = decimal.TryParse(txtAmount.Text, out dummy);       
            if (dummy <= 0 )
            { btnCalculate.Enabled = false; }

        }


    }
  
}
