﻿namespace LabExercise1
{
    partial class BillCalculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAmount = new System.Windows.Forms.Label();
            this.lblTaxRate = new System.Windows.Forms.Label();
            this.lblTipPercent = new System.Windows.Forms.Label();
            this.txtAmount = new System.Windows.Forms.TextBox();
            this.txtTaxRate = new System.Windows.Forms.TextBox();
            this.txtTipPercentage = new System.Windows.Forms.TextBox();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.grpboxResults = new System.Windows.Forms.GroupBox();
            this.lblNumTotal = new System.Windows.Forms.Label();
            this.lblNumTip = new System.Windows.Forms.Label();
            this.lblNumTax = new System.Windows.Forms.Label();
            this.lblNumAmount = new System.Windows.Forms.Label();
            this.lblResTotal = new System.Windows.Forms.Label();
            this.lblResTip = new System.Windows.Forms.Label();
            this.lblResTax = new System.Windows.Forms.Label();
            this.lblResAmount = new System.Windows.Forms.Label();
            this.grpboxResults.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblAmount
            // 
            this.lblAmount.AutoSize = true;
            this.lblAmount.Location = new System.Drawing.Point(14, 22);
            this.lblAmount.Name = "lblAmount";
            this.lblAmount.Size = new System.Drawing.Size(43, 13);
            this.lblAmount.TabIndex = 0;
            this.lblAmount.Text = "&Amount";
            // 
            // lblTaxRate
            // 
            this.lblTaxRate.AutoSize = true;
            this.lblTaxRate.Location = new System.Drawing.Point(14, 52);
            this.lblTaxRate.Name = "lblTaxRate";
            this.lblTaxRate.Size = new System.Drawing.Size(51, 13);
            this.lblTaxRate.TabIndex = 2;
            this.lblTaxRate.Text = "Tax &Rate";
            // 
            // lblTipPercent
            // 
            this.lblTipPercent.AutoSize = true;
            this.lblTipPercent.Location = new System.Drawing.Point(14, 82);
            this.lblTipPercent.Name = "lblTipPercent";
            this.lblTipPercent.Size = new System.Drawing.Size(80, 13);
            this.lblTipPercent.TabIndex = 4;
            this.lblTipPercent.Text = "&Tip Percentage";
            // 
            // txtAmount
            // 
            this.txtAmount.Location = new System.Drawing.Point(129, 15);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.Size = new System.Drawing.Size(100, 20);
            this.txtAmount.TabIndex = 1;
            this.txtAmount.TextChanged += new System.EventHandler(this.txtAmount_TextChanged);
            // 
            // txtTaxRate
            // 
            this.txtTaxRate.Location = new System.Drawing.Point(129, 45);
            this.txtTaxRate.Name = "txtTaxRate";
            this.txtTaxRate.Size = new System.Drawing.Size(100, 20);
            this.txtTaxRate.TabIndex = 3;
            // 
            // txtTipPercentage
            // 
            this.txtTipPercentage.Location = new System.Drawing.Point(129, 75);
            this.txtTipPercentage.Name = "txtTipPercentage";
            this.txtTipPercentage.Size = new System.Drawing.Size(100, 20);
            this.txtTipPercentage.TabIndex = 5;
            // 
            // btnCalculate
            // 
            this.btnCalculate.Enabled = false;
            this.btnCalculate.Location = new System.Drawing.Point(154, 105);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(75, 23);
            this.btnCalculate.TabIndex = 6;
            this.btnCalculate.Text = "&Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // grpboxResults
            // 
            this.grpboxResults.Controls.Add(this.lblNumTotal);
            this.grpboxResults.Controls.Add(this.lblNumTip);
            this.grpboxResults.Controls.Add(this.lblNumTax);
            this.grpboxResults.Controls.Add(this.lblNumAmount);
            this.grpboxResults.Controls.Add(this.lblResTotal);
            this.grpboxResults.Controls.Add(this.lblResTip);
            this.grpboxResults.Controls.Add(this.lblResTax);
            this.grpboxResults.Controls.Add(this.lblResAmount);
            this.grpboxResults.Location = new System.Drawing.Point(17, 138);
            this.grpboxResults.Name = "grpboxResults";
            this.grpboxResults.Size = new System.Drawing.Size(212, 149);
            this.grpboxResults.TabIndex = 7;
            this.grpboxResults.TabStop = false;
            this.grpboxResults.Text = "Results";
            // 
            // lblNumTotal
            // 
            this.lblNumTotal.Location = new System.Drawing.Point(105, 112);
            this.lblNumTotal.Name = "lblNumTotal";
            this.lblNumTotal.Size = new System.Drawing.Size(94, 13);
            this.lblNumTotal.TabIndex = 7;
            this.lblNumTotal.Text = "$0.00";
            this.lblNumTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblNumTip
            // 
            this.lblNumTip.Location = new System.Drawing.Point(102, 84);
            this.lblNumTip.Name = "lblNumTip";
            this.lblNumTip.Size = new System.Drawing.Size(97, 13);
            this.lblNumTip.TabIndex = 5;
            this.lblNumTip.Text = "$0.00";
            this.lblNumTip.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblNumTax
            // 
            this.lblNumTax.Location = new System.Drawing.Point(112, 56);
            this.lblNumTax.Name = "lblNumTax";
            this.lblNumTax.Size = new System.Drawing.Size(87, 13);
            this.lblNumTax.TabIndex = 3;
            this.lblNumTax.Text = "$0.00";
            this.lblNumTax.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblNumAmount
            // 
            this.lblNumAmount.Location = new System.Drawing.Point(137, 28);
            this.lblNumAmount.Name = "lblNumAmount";
            this.lblNumAmount.Size = new System.Drawing.Size(62, 13);
            this.lblNumAmount.TabIndex = 1;
            this.lblNumAmount.Text = "$0.00";
            this.lblNumAmount.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblResTotal
            // 
            this.lblResTotal.AutoSize = true;
            this.lblResTotal.Location = new System.Drawing.Point(13, 112);
            this.lblResTotal.Name = "lblResTotal";
            this.lblResTotal.Size = new System.Drawing.Size(31, 13);
            this.lblResTotal.TabIndex = 6;
            this.lblResTotal.Text = "Total";
            // 
            // lblResTip
            // 
            this.lblResTip.AutoSize = true;
            this.lblResTip.Location = new System.Drawing.Point(13, 84);
            this.lblResTip.Name = "lblResTip";
            this.lblResTip.Size = new System.Drawing.Size(22, 13);
            this.lblResTip.TabIndex = 4;
            this.lblResTip.Text = "Tip";
            // 
            // lblResTax
            // 
            this.lblResTax.AutoSize = true;
            this.lblResTax.Location = new System.Drawing.Point(13, 56);
            this.lblResTax.Name = "lblResTax";
            this.lblResTax.Size = new System.Drawing.Size(25, 13);
            this.lblResTax.TabIndex = 2;
            this.lblResTax.Text = "Tax";
            // 
            // lblResAmount
            // 
            this.lblResAmount.AutoSize = true;
            this.lblResAmount.Location = new System.Drawing.Point(13, 28);
            this.lblResAmount.Name = "lblResAmount";
            this.lblResAmount.Size = new System.Drawing.Size(43, 13);
            this.lblResAmount.TabIndex = 0;
            this.lblResAmount.Text = "Amount";
            // 
            // BillCalculator
            // 
            this.AcceptButton = this.btnCalculate;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(252, 299);
            this.Controls.Add(this.grpboxResults);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.txtTipPercentage);
            this.Controls.Add(this.txtTaxRate);
            this.Controls.Add(this.txtAmount);
            this.Controls.Add(this.lblTipPercent);
            this.Controls.Add(this.lblTaxRate);
            this.Controls.Add(this.lblAmount);
            this.Name = "BillCalculator";
            this.Text = "Bill Calculator";
            this.grpboxResults.ResumeLayout(false);
            this.grpboxResults.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAmount;
        private System.Windows.Forms.Label lblTaxRate;
        private System.Windows.Forms.Label lblTipPercent;
        private System.Windows.Forms.TextBox txtAmount;
        private System.Windows.Forms.TextBox txtTaxRate;
        private System.Windows.Forms.TextBox txtTipPercentage;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.GroupBox grpboxResults;
        private System.Windows.Forms.Label lblNumTotal;
        private System.Windows.Forms.Label lblNumTip;
        private System.Windows.Forms.Label lblNumTax;
        private System.Windows.Forms.Label lblNumAmount;
        private System.Windows.Forms.Label lblResTotal;
        private System.Windows.Forms.Label lblResTip;
        private System.Windows.Forms.Label lblResTax;
        private System.Windows.Forms.Label lblResAmount;

    }
}

