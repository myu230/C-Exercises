﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LabExercise2
{
    public partial class SlotGame : Form
    {
        public SlotGame()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnPlay_Click(object sender, EventArgs e)
        {
            Random rndNum;
            rndNum = new Random();
            int numSlot1, numSlot2, numSlot3;
            numSlot1 = rndNum.Next(1, 10);
            numSlot2 = rndNum.Next(1, 10);
            numSlot3 = rndNum.Next(1, 10);

            lblSlot1.Text = Convert.ToString(numSlot1);
            lblSlot2.Text = Convert.ToString(numSlot2);
            lblSlot3.Text = Convert.ToString(numSlot3);
            
            if (numSlot1 == numSlot2 && numSlot1 == numSlot3)
            {
                lblMessage.Text = "You Win!!!";
            }
            else 
            {
                lblMessage.Text = "No win. Play again";
            }

        }
    }
}
