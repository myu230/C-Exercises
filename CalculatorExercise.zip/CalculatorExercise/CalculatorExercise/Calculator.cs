﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorExercise
{
    class Calculator
    {
        private double m_dValueA = 0.0, m_dValueB = 0.0;

        public double ValueA
        {
            get
            {
                return m_dValueA;
            }
            set
            {
                m_dValueA = value;
            }
        }

        public double ValueB
        {
            get
            {
                return m_dValueB;
            }
            set
            {
                m_dValueB = value;
            }
        }

        public void Add()
        {
            ValueA += ValueB;
        }

        public void Subtract()
        {
            ValueA -= ValueB;
        }

        public void Multiply()
        {
            ValueA *= ValueB;
        }

        public void Divide()
        {
            if (ValueB == 0)
            {
                ValueA = 0;
            }
            else
            {
                ValueA /= ValueB;
            }
        }
    }
}
