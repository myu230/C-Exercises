﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculatorExercise
{
    public partial class CalculatorExercise : Form
    {
        private Calculator m_Calc = new Calculator();

        public CalculatorExercise()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            m_Calc.Add();
            txtValueA.Text = Convert.ToString(m_Calc.ValueA);
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            m_Calc.Subtract();
            txtValueA.Text = Convert.ToString(m_Calc.ValueA);
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            m_Calc.Multiply();
            txtValueA.Text = Convert.ToString(m_Calc.ValueA);
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            m_Calc.Divide();
            txtValueA.Text = Convert.ToString(m_Calc.ValueA);
        }

        private void txtValue_TextChanged(object sender, EventArgs e)
        {
            double dummyA, dummyB;
            bool bvalueA, bValueB;
            bvalueA = double.TryParse(txtValueA.Text, out dummyA);
            bValueB = double.TryParse(txtValueB.Text, out dummyB);
            btnAdd.Enabled = btnSub.Enabled = btnMult.Enabled = btnDiv.Enabled = (bvalueA && bValueB);
            m_Calc.ValueA = dummyA;
            m_Calc.ValueB = dummyB;
        }

    }
}
