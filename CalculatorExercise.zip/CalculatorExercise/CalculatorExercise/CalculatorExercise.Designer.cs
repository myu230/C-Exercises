﻿namespace CalculatorExercise
{
    partial class CalculatorExercise
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnDiv = new System.Windows.Forms.Button();
            this.btnMult = new System.Windows.Forms.Button();
            this.btnSub = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.txtValueB = new System.Windows.Forms.TextBox();
            this.txtValueA = new System.Windows.Forms.TextBox();
            this.lblValueB = new System.Windows.Forms.Label();
            this.lblValueA = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnDiv
            // 
            this.btnDiv.Enabled = false;
            this.btnDiv.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDiv.Location = new System.Drawing.Point(193, 75);
            this.btnDiv.Name = "btnDiv";
            this.btnDiv.Size = new System.Drawing.Size(52, 49);
            this.btnDiv.TabIndex = 7;
            this.btnDiv.Text = "/";
            this.btnDiv.UseVisualStyleBackColor = true;
            this.btnDiv.Click += new System.EventHandler(this.btnDiv_Click);
            // 
            // btnMult
            // 
            this.btnMult.Enabled = false;
            this.btnMult.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMult.Location = new System.Drawing.Point(135, 75);
            this.btnMult.Name = "btnMult";
            this.btnMult.Size = new System.Drawing.Size(52, 49);
            this.btnMult.TabIndex = 6;
            this.btnMult.Text = "x";
            this.btnMult.UseVisualStyleBackColor = true;
            this.btnMult.Click += new System.EventHandler(this.btnMult_Click);
            // 
            // btnSub
            // 
            this.btnSub.Enabled = false;
            this.btnSub.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSub.Location = new System.Drawing.Point(77, 75);
            this.btnSub.Name = "btnSub";
            this.btnSub.Size = new System.Drawing.Size(52, 49);
            this.btnSub.TabIndex = 5;
            this.btnSub.Text = "-";
            this.btnSub.UseVisualStyleBackColor = true;
            this.btnSub.Click += new System.EventHandler(this.btnSub_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Enabled = false;
            this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.Location = new System.Drawing.Point(16, 75);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(52, 49);
            this.btnAdd.TabIndex = 4;
            this.btnAdd.Text = "+";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // txtValueB
            // 
            this.txtValueB.Location = new System.Drawing.Point(77, 40);
            this.txtValueB.Name = "txtValueB";
            this.txtValueB.Size = new System.Drawing.Size(168, 20);
            this.txtValueB.TabIndex = 3;
            this.txtValueB.TextChanged += new System.EventHandler(this.txtValue_TextChanged);
            // 
            // txtValueA
            // 
            this.txtValueA.Location = new System.Drawing.Point(77, 14);
            this.txtValueA.Name = "txtValueA";
            this.txtValueA.Size = new System.Drawing.Size(168, 20);
            this.txtValueA.TabIndex = 1;
            this.txtValueA.TextChanged += new System.EventHandler(this.txtValue_TextChanged);
            // 
            // lblValueB
            // 
            this.lblValueB.AutoSize = true;
            this.lblValueB.Location = new System.Drawing.Point(17, 43);
            this.lblValueB.Name = "lblValueB";
            this.lblValueB.Size = new System.Drawing.Size(44, 13);
            this.lblValueB.TabIndex = 2;
            this.lblValueB.Text = "Value &B";
            // 
            // lblValueA
            // 
            this.lblValueA.AutoSize = true;
            this.lblValueA.Location = new System.Drawing.Point(17, 14);
            this.lblValueA.Name = "lblValueA";
            this.lblValueA.Size = new System.Drawing.Size(44, 13);
            this.lblValueA.TabIndex = 0;
            this.lblValueA.Text = "Value &A";
            // 
            // CalculatorExercise
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(261, 139);
            this.Controls.Add(this.btnDiv);
            this.Controls.Add(this.btnMult);
            this.Controls.Add(this.btnSub);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.txtValueB);
            this.Controls.Add(this.txtValueA);
            this.Controls.Add(this.lblValueB);
            this.Controls.Add(this.lblValueA);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "CalculatorExercise";
            this.Text = "Calculator Exercise";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Button btnDiv;
        internal System.Windows.Forms.Button btnMult;
        internal System.Windows.Forms.Button btnSub;
        internal System.Windows.Forms.Button btnAdd;
        internal System.Windows.Forms.TextBox txtValueB;
        internal System.Windows.Forms.TextBox txtValueA;
        internal System.Windows.Forms.Label lblValueB;
        internal System.Windows.Forms.Label lblValueA;
    }
}

