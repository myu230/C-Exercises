﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LabTestHorseRace
{
    public partial class HorseRaceForm : Form
    {
        private Horse[] m_horses = { new Horse(), new Horse() };

        public HorseRaceForm()
        {
            InitializeComponent();
            m_horses[0].PositionChanged += m_horses_Horse1Changed;
            m_horses[1].PositionChanged += m_horses_Horse2Changed;
        }

        ~HorseRaceForm()
        {
            m_horses[0].PositionChanged -= m_horses_Horse1Changed;
            m_horses[1].PositionChanged -= m_horses_Horse2Changed;
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            btnStart.Enabled = false;
            timerRace.Start();
        }

        private void timerRace_Tick(object sender, EventArgs e)
        {
            for (int i = 0; i < m_horses.Length; i++)
                m_horses[i].Run();

            if (m_horses[0].Position == 50 && m_horses[1].Position == 50)
            {
                lbWinner.Text = "Tie Race!";
                timerRace.Stop();
            }
            else if (m_horses[0].Position == 50)
            {
                lbWinner.Text = lbHorse1.Text + " has won!";
                timerRace.Stop();
            }
            else if (m_horses[1].Position == 50)
            {
                lbWinner.Text = lbHorse2.Text + " has won!";
                timerRace.Stop();
            }
        }

        private void m_horses_Horse1Changed(object sender, EventArgs e)
        {
            pbHorse1.Value = m_horses[0].Position;
        }

        private void m_horses_Horse2Changed(object sender, EventArgs e)
        {
            pbHorse2.Value = m_horses[1].Position;
        }

    }
}
