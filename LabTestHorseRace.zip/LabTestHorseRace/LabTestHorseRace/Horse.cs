﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabTestHorseRace
{
    class Horse
    {
        public int Position { get; private set;}
        private static Random m_rnd = new Random();

        public Horse()
        {
            Position = 0;
        }

        public event EventHandler PositionChanged;

        public void Run()
        {
            int horseRun;

            if (Position < 50)
            {
                horseRun = m_rnd.Next(1, 3);
                Position += horseRun;

                if (Position > 50)
                {
                    Position = 50;
                }

                if (PositionChanged != null)
                {
                    PositionChanged(this, new EventArgs());
                }
            }
        }
    }
}
