﻿namespace LabTestHorseRace
{
    partial class HorseRaceForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnStart = new System.Windows.Forms.Button();
            this.lbHorse1 = new System.Windows.Forms.Label();
            this.lbHorse2 = new System.Windows.Forms.Label();
            this.lbWinner = new System.Windows.Forms.Label();
            this.pbHorse1 = new System.Windows.Forms.ProgressBar();
            this.pbHorse2 = new System.Windows.Forms.ProgressBar();
            this.timerRace = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(22, 96);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(75, 23);
            this.btnStart.TabIndex = 4;
            this.btnStart.Text = "&Start Race";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // lbHorse1
            // 
            this.lbHorse1.AutoSize = true;
            this.lbHorse1.Location = new System.Drawing.Point(19, 25);
            this.lbHorse1.Name = "lbHorse1";
            this.lbHorse1.Size = new System.Drawing.Size(64, 13);
            this.lbHorse1.TabIndex = 0;
            this.lbHorse1.Text = "Quick Silver";
            // 
            // lbHorse2
            // 
            this.lbHorse2.AutoSize = true;
            this.lbHorse2.Location = new System.Drawing.Point(19, 63);
            this.lbHorse2.Name = "lbHorse2";
            this.lbHorse2.Size = new System.Drawing.Size(56, 13);
            this.lbHorse2.TabIndex = 2;
            this.lbHorse2.Text = "Ol\' Faithful";
            // 
            // lbWinner
            // 
            this.lbWinner.AutoSize = true;
            this.lbWinner.Location = new System.Drawing.Point(123, 101);
            this.lbWinner.Name = "lbWinner";
            this.lbWinner.Size = new System.Drawing.Size(0, 13);
            this.lbWinner.TabIndex = 5;
            // 
            // pbHorse1
            // 
            this.pbHorse1.Location = new System.Drawing.Point(126, 15);
            this.pbHorse1.Maximum = 50;
            this.pbHorse1.Name = "pbHorse1";
            this.pbHorse1.Size = new System.Drawing.Size(368, 23);
            this.pbHorse1.TabIndex = 1;
            // 
            // pbHorse2
            // 
            this.pbHorse2.Location = new System.Drawing.Point(126, 53);
            this.pbHorse2.Maximum = 50;
            this.pbHorse2.Name = "pbHorse2";
            this.pbHorse2.Size = new System.Drawing.Size(368, 23);
            this.pbHorse2.TabIndex = 3;
            // 
            // timerRace
            // 
            this.timerRace.Tick += new System.EventHandler(this.timerRace_Tick);
            // 
            // HorseRaceForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(512, 134);
            this.Controls.Add(this.pbHorse2);
            this.Controls.Add(this.pbHorse1);
            this.Controls.Add(this.lbWinner);
            this.Controls.Add(this.lbHorse2);
            this.Controls.Add(this.lbHorse1);
            this.Controls.Add(this.btnStart);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "HorseRaceForm";
            this.Text = "Horse Race";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Label lbHorse1;
        private System.Windows.Forms.Label lbHorse2;
        private System.Windows.Forms.Label lbWinner;
        private System.Windows.Forms.ProgressBar pbHorse1;
        private System.Windows.Forms.ProgressBar pbHorse2;
        private System.Windows.Forms.Timer timerRace;
    }
}

